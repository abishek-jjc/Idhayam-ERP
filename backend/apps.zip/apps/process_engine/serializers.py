from rest_framework import serializers
from .models import (
    ProcessType, ProcessAttributeDefinition, ProcessInstance,
    ProcessAttributeValue, ProcessLink, AdminVerification
)

class ProcessAttributeDefinitionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProcessAttributeDefinition
        fields = '__all__'

class ProcessTypeSerializer(serializers.ModelSerializer):
    attribute_definitions = ProcessAttributeDefinitionSerializer(many=True, read_only=True)
    owning_department_name = serializers.ReadOnlyField(source='owning_department.name')

    class Meta:
        model = ProcessType
        fields = '__all__'

class ProcessAttributeValueSerializer(serializers.ModelSerializer):
    attribute_code = serializers.ReadOnlyField(source='attribute_definition.attribute_code')
    attribute_name = serializers.ReadOnlyField(source='attribute_definition.attribute_name')
    data_type = serializers.ReadOnlyField(source='attribute_definition.data_type')

    class Meta:
        model = ProcessAttributeValue
        fields = '__all__'

class ProcessInstanceSerializer(serializers.ModelSerializer):
    process_type_name = serializers.ReadOnlyField(source='process_type.name')
    process_type_code = serializers.ReadOnlyField(source='process_type.code')
    plant_name = serializers.ReadOnlyField(source='plant.name')
    department_name = serializers.ReadOnlyField(source='department.name')
    performed_by_name = serializers.ReadOnlyField(source='performed_by.name')
    attribute_values = ProcessAttributeValueSerializer(many=True, read_only=True)

    class Meta:
        model = ProcessInstance
        fields = '__all__'

class ProcessInstanceCreateSerializer(serializers.ModelSerializer):
    """
    Serializer for creating instance with dynamic attribute values map.
    values = { "attribute_code": value, ... }
    """
    values = serializers.JSONField(write_only=True, required=False, default=dict)

    class Meta:
        model = ProcessInstance
        fields = '__all__'

    def create(self, validated_data):
        values_data = validated_data.pop('values', {})
        instance = ProcessInstance.objects.create(**validated_data)
        
        # Save dynamic values according to attribute definition data types
        definitions = ProcessAttributeDefinition.objects.filter(process_type=instance.process_type)
        for attr_def in definitions:
            val = values_data.get(attr_def.attribute_code)
            if val is not None and val != "":
                val_kwargs = {
                    'process_instance': instance,
                    'attribute_definition': attr_def,
                }
                dt = attr_def.data_type
                if dt == 'text':
                    val_kwargs['value_text'] = str(val)
                elif dt == 'number':
                    val_kwargs['value_number'] = val
                elif dt == 'date':
                    val_kwargs['value_date'] = val
                elif dt == 'datetime':
                    val_kwargs['value_datetime'] = val
                elif dt == 'boolean':
                    val_kwargs['value_boolean'] = bool(val)
                elif dt == 'reference':
                    val_kwargs['value_reference_id'] = val
                
                ProcessAttributeValue.objects.create(**val_kwargs)
        return instance

class ProcessLinkSerializer(serializers.ModelSerializer):
    from_process_name = serializers.ReadOnlyField(source='from_process_instance.process_type.name')
    to_process_name = serializers.ReadOnlyField(source='to_process_instance.process_type.name')

    class Meta:
        model = ProcessLink
        fields = '__all__'

class AdminVerificationSerializer(serializers.ModelSerializer):
    verified_by_name = serializers.ReadOnlyField(source='verified_by.name')

    class Meta:
        model = AdminVerification
        fields = '__all__'
