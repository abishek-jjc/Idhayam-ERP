import datetime
import threading
from django.db import models

_seq_lock = threading.Lock()
_seq_counters = {}

def _get_max_seq_from_db(prefix_key):
    try:
        from django.apps import apps
        max_seq = 0
        pattern = f"{prefix_key}-"
        for model in apps.get_models():
            if hasattr(model, 'id') and hasattr(model._meta, 'pk') and isinstance(model._meta.pk, models.CharField):
                try:
                    matches = model.objects.filter(id__startswith=pattern).values_list('id', flat=True)
                    for pk_val in matches:
                        try:
                            seq_part = int(pk_val.rsplit('-', 1)[-1])
                            if seq_part > max_seq:
                                max_seq = seq_part
                        except (ValueError, IndexError):
                            pass
                except Exception:
                    pass
        return max_seq
    except Exception:
        return 0

def generate_custom_pk(prefix="ERP"):
    now = datetime.datetime.now()
    date_str = now.strftime("%d-%m-%Y")
    key = f"{prefix.upper()}-{date_str}"
    with _seq_lock:
        if key not in _seq_counters:
            _seq_counters[key] = _get_max_seq_from_db(key)
        _seq_counters[key] += 1
        seq = _seq_counters[key]
    return f"{key}-{seq:04d}"

def pk_cmp(): return generate_custom_pk("CMP")
def pk_pln(): return generate_custom_pk("PLN")
def pk_dpt(): return generate_custom_pk("DPT")
def pk_dsg(): return generate_custom_pk("DSG")
def pk_emp(): return generate_custom_pk("EMP")
def pk_edt(): return generate_custom_pk("EDT")
def pk_bnk(): return generate_custom_pk("BNK")
def pk_rol(): return generate_custom_pk("ROL")
def pk_emr(): return generate_custom_pk("EMR")
def pk_prm(): return generate_custom_pk("PRM")
def pk_vnd(): return generate_custom_pk("VND")
def pk_mac(): return generate_custom_pk("MAC")
def pk_blk(): return generate_custom_pk("BLK")
def pk_bin(): return generate_custom_pk("BIN")
def pk_doc(): return generate_custom_pk("DOC")
def pk_coa(): return generate_custom_pk("COA")

class Company(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_cmp, editable=False)
    name = models.CharField(max_length=200)
    gst_number = models.CharField(max_length=20, blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Plant(models.Model):
    PLANT_TYPES = [
        ('manufacturing', 'Manufacturing'),
        ('transport', 'Transport'),
    ]
    id = models.CharField(primary_key=True, max_length=50, default=pk_pln, editable=False)
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='plants')
    name = models.CharField(max_length=150)
    plant_type = models.CharField(max_length=30, choices=PLANT_TYPES, default='manufacturing')
    is_active = models.BooleanField(default=True)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.plant_type})"

class Department(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_dpt, editable=False)
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name='departments', null=True, blank=True)
    name = models.CharField(max_length=150)
    is_shared_across_plants = models.BooleanField(default=False)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Designation(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_dsg, editable=False)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='designations')
    title = models.CharField(max_length=150)
    hierarchy_level = models.IntegerField(default=1)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - Level {self.hierarchy_level}"

class Employee(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('terminated', 'Terminated'),
    ]
    id = models.CharField(primary_key=True, max_length=50, default=pk_emp, editable=False)
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, blank=True, related_name='employees')
    designation = models.ForeignKey(Designation, on_delete=models.SET_NULL, null=True, blank=True, related_name='employees')
    plant = models.ForeignKey(Plant, on_delete=models.SET_NULL, null=True, blank=True, related_name='employees')
    name = models.CharField(max_length=150)
    user_account_id = models.CharField(max_length=50, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        desig_str = self.designation.title if self.designation else "Staff"
        return f"{self.name} ({desig_str})"

class EmployeeDetail(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_edt, editable=False)
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE, related_name='details')
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=20, blank=True, null=True)
    contact_number = models.CharField(max_length=20, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    date_of_joining = models.DateField(null=True, blank=True)
    emergency_contact_name = models.CharField(max_length=150, blank=True, null=True)
    emergency_contact_number = models.CharField(max_length=20, blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)

class EmployeeBankAccount(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_bnk, editable=False)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='bank_accounts')
    bank_name = models.CharField(max_length=150)
    account_holder_name = models.CharField(max_length=150)
    account_number = models.CharField(max_length=40)
    ifsc_code = models.CharField(max_length=20)
    is_primary = models.BooleanField(default=True)
    remarks = models.TextField(blank=True, null=True)

class Role(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_rol, editable=False)
    name = models.CharField(max_length=100, unique=True)
    remarks = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

class EmployeeRole(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_emr, editable=False)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='roles')
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name='employees')

    class Meta:
        unique_together = ('employee', 'role')

class Permission(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_prm, editable=False)
    designation = models.ForeignKey(Designation, on_delete=models.CASCADE, related_name='permissions', null=True, blank=True)
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name='permissions', null=True, blank=True)
    module = models.CharField(max_length=80)  # dashboard, structural_masters, dynamic_masters, process_engine, workflow, journal, admin
    process_type = models.ForeignKey('process_engine.ProcessType', on_delete=models.CASCADE, related_name='permissions', null=True, blank=True)
    master_category = models.ForeignKey('masters.MasterCategory', on_delete=models.CASCADE, related_name='permissions', null=True, blank=True)
    action = models.CharField(max_length=40, blank=True, null=True)
    can_view = models.BooleanField(default=True)
    can_create = models.BooleanField(default=False)
    can_edit = models.BooleanField(default=False)
    can_delete = models.BooleanField(default=False)
    can_approve = models.BooleanField(default=False)

    class Meta:
        ordering = ['id']

    def __str__(self):
        target = self.designation.title if self.designation else (self.role.name if self.role else 'Global')
        pt = f" [{self.process_type.name}]" if self.process_type else ""
        return f"{target} -> {self.module}{pt}"


class Vendor(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_vnd, editable=False)
    name = models.CharField(max_length=200)
    gst_number = models.CharField(max_length=20, blank=True, null=True)
    contact_info = models.JSONField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Machine(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('maintenance', 'Under Maintenance'),
        ('inactive', 'Inactive'),
    ]
    id = models.CharField(primary_key=True, max_length=50, default=pk_mac, editable=False)
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name='machines')
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='machines')
    machine_type_id = models.CharField(max_length=50, null=True, blank=True)
    code = models.CharField(max_length=40, unique=True)
    name = models.CharField(max_length=150)
    capacity = models.DecimalField(max_digits=14, decimal_places=3, null=True, blank=True)
    registration_number = models.CharField(max_length=30, unique=True, null=True, blank=True)
    fastag_number = models.CharField(max_length=30, null=True, blank=True)
    fastag_status = models.CharField(max_length=20, default='active', null=True, blank=True)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='active')
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} [{self.code}]"

class StorageLocationBlock(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_blk, editable=False)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='blocks')
    start_code = models.CharField(max_length=4)
    end_code = models.CharField(max_length=4)
    remarks = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Block {self.start_code}-{self.end_code} ({self.department.name})"

class StorageLocation(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_bin, editable=False)
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name='storage_locations')
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='storage_locations')
    storage_location_block = models.ForeignKey(StorageLocationBlock, on_delete=models.CASCADE, related_name='locations')
    code = models.CharField(max_length=4)
    capacity = models.DecimalField(max_digits=14, decimal_places=3, null=True, blank=True)
    status = models.CharField(max_length=30, default='active')
    remarks = models.TextField(blank=True, null=True)

    class Meta:
        unique_together = ('plant', 'code')

    def __str__(self):
        return f"Bin {self.code} ({self.department.name})"

class Document(models.Model):
    id = models.CharField(primary_key=True, max_length=50, default=pk_doc, editable=False)
    entity_table = models.CharField(max_length=80)
    entity_id = models.CharField(max_length=50)
    file_path = models.CharField(max_length=500)
    version_no = models.IntegerField(default=1)
    uploaded_by = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='uploaded_documents')
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

class ChartOfAccount(models.Model):
    ACCOUNT_TYPES = [
        ('asset', 'Asset'),
        ('liability', 'Liability'),
        ('income', 'Income'),
        ('expense', 'Expense'),
    ]
    id = models.CharField(primary_key=True, max_length=50, default=pk_coa, editable=False)
    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=150)
    account_type = models.CharField(max_length=20, choices=ACCOUNT_TYPES)
    remarks = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.code} - {self.name} [{self.account_type}]"
