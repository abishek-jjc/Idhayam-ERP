import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Bell, Search, Shield, Zap, Sparkles, LogOut, UserCheck } from 'lucide-react';

export default function Navbar({ title }) {
  const { user, designation, isSuperAdmin, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="h-16 bg-slate-900/60 backdrop-blur-xl border-b border-white/10 sticky top-0 z-20 flex items-center justify-between px-6 w-full">
      <div className="flex items-center gap-3">
        <div className="p-1.5 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400">
          <Sparkles className="w-4 h-4 animate-pulse" />
        </div>
        <h2 className="text-lg font-bold text-white tracking-tight">{title}</h2>
        <span className="badge badge-active flex items-center gap-1 text-[10px] py-0.5 px-2">
          <Zap className="w-3 h-3 fill-current text-emerald-400" /> Live Enterprise
        </span>
      </div>

      <div className="flex items-center gap-4">
        {/* User Profile Tag */}
        <div className="flex items-center gap-3 pl-3 border-l border-white/10">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 p-[1px] shadow-lg shadow-indigo-500/20">
            <div className="w-full h-full rounded-xl bg-slate-950 flex items-center justify-center text-white font-extrabold text-xs">
              {isSuperAdmin ? 'SA' : (designation?.title?.[0] || 'U')}
            </div>
          </div>
          <div className="hidden sm:block">
            <div className="flex items-center gap-1.5">
              <p className="text-xs font-bold text-white">{user?.name || 'Guest Operator'}</p>
              {isSuperAdmin && <Shield className="w-3.5 h-3.5 text-purple-400 fill-purple-400/20" />}
            </div>
            <p className="text-[10px] text-indigo-400 font-mono font-semibold">
              {isSuperAdmin ? 'Super Administrator' : (designation?.title || 'Designation User')}
            </p>
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={handleLogout}
          title="Sign Out"
          className="p-2 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:text-red-400 hover:bg-red-500/10 hover:border-red-500/30 transition-all flex items-center gap-1 text-xs font-semibold"
        >
          <LogOut className="w-4 h-4" />
          <span className="hidden lg:inline">Logout</span>
        </button>
      </div>
    </header>
  );
}
