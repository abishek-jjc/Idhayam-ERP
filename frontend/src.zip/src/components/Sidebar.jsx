import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, UserCheck, ShieldCheck, Building2, Layers, Cpu, GitPullRequest, BookOpenCheck, LogIn, Database } from 'lucide-react';

export default function Sidebar() {
  const { user, designation, isSuperAdmin, hasPermission } = useAuth();

  const navItems = [
    { path: '/', label: 'Dashboard', icon: LayoutDashboard, module: 'dashboard' },
    { path: '/user', label: 'User Portal Page', icon: UserCheck, module: 'user_page' },
    { path: '/admin-console', label: 'SuperAdmin Console', icon: ShieldCheck, module: 'admin' },
    { path: '/structural-masters', label: 'Structural Masters', icon: Building2, module: 'structural_masters' },
    { path: '/dynamic-masters', label: 'Dynamic Masters (EAV)', icon: Layers, module: 'dynamic_masters' },
    { path: '/process-engine', label: 'Process Engine', icon: Cpu, module: 'process_engine' },
    { path: '/workflow-approvals', label: 'Workflow & Approvals', icon: GitPullRequest, module: 'workflow' },
    { path: '/journal-stock', label: 'Journal & Stock Ledger', icon: BookOpenCheck, module: 'journal' },
    { path: '/login', label: 'Sign In Page', icon: LogIn, alwaysVisible: true },
  ];

  return (
    <aside className="sidebar">
      {/* Brand Header */}
      <div className="p-5 border-b border-white/10 flex items-center gap-3 bg-slate-950/40">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-lg shadow-lg shadow-blue-500/25">
          E2
        </div>
        <div>
          <h1 className="text-base font-extrabold text-white tracking-tight leading-tight">
            ERP <span className="gradient-text">v2</span>
          </h1>
          <p className="text-[10px] text-slate-400 font-semibold tracking-wider uppercase">Generic Access Engine</p>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 p-3 overflow-y-auto space-y-1.5 custom-scrollbar">
        {navItems.map((item) => {
          if (!item.alwaysVisible && !isSuperAdmin && item.module !== 'user_page' && item.module !== 'dashboard') {
            if (!hasPermission(item.module)) return null;
          }

          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="text-xs font-semibold">{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Designation User Footer */}
      <div className="p-4 border-t border-white/10 bg-slate-950/80">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center border border-indigo-500/30 font-bold text-xs">
            {isSuperAdmin ? 'SA' : (designation?.title?.[0] || 'U')}
          </div>
          <div className="overflow-hidden">
            <p className="text-xs font-bold text-slate-200 truncate">{user?.name || 'Guest User'}</p>
            <p className="text-[10px] font-mono text-purple-400 truncate">
              {isSuperAdmin ? 'Super Administrator' : (designation?.title || 'No Designation')}
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
}
