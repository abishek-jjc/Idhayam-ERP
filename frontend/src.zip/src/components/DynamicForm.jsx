import React, { useState } from 'react';

export default function DynamicForm({ definitions, onSubmit, onCancel, plants, departments, employees, masterItems, storageLocations }) {
  const [formData, setFormData] = useState({
    plant: plants[0]?.id || '',
    department: departments[0]?.id || '',
    performed_by: employees[0]?.id || '',
    remarks: '',
    values: {},
  });

  const handleValueChange = (code, val) => {
    setFormData((prev) => ({
      ...prev,
      values: {
        ...prev.values,
        [code]: val,
      },
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4 pb-4 border-b border-white/10">
        <div>
          <label className="form-label">Plant *</label>
          <select
            value={formData.plant}
            onChange={(e) => setFormData({ ...formData, plant: e.target.value })}
            className="form-input"
            required
          >
            <option value="">Select Plant</option>
            {plants.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="form-label">Department *</label>
          <select
            value={formData.department}
            onChange={(e) => setFormData({ ...formData, department: e.target.value })}
            className="form-input"
            required
          >
            <option value="">Select Department</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
        </div>

        <div className="col-span-2">
          <label className="form-label">Performed By (Employee)</label>
          <select
            value={formData.performed_by}
            onChange={(e) => setFormData({ ...formData, performed_by: e.target.value })}
            className="form-input"
          >
            <option value="">Select Operator / Officer</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.id}>{emp.name} ({emp.designation_title || 'Employee'})</option>
            ))}
          </select>
        </div>
      </div>

      <div className="space-y-4 pt-2">
        <h4 className="text-sm font-bold text-blue-400 uppercase tracking-wider">Dynamic Process Attributes</h4>

        {definitions.length === 0 && (
          <p className="text-xs text-slate-500 italic">No dynamic attributes defined for this process type yet.</p>
        )}

        {definitions.map((def) => {
          const val = formData.values[def.attribute_code] || '';

          if (def.data_type === 'reference') {
            let refOptions = [];
            if (def.reference_table === 'employee') refOptions = employees.map(e => ({ id: e.id, name: e.name }));
            else if (def.reference_table === 'storage_location') refOptions = storageLocations.map(s => ({ id: s.id, name: `Bin ${s.code}` }));
            else refOptions = masterItems.map(m => ({ id: m.id, name: `${m.name} (${m.code})` }));

            return (
              <div key={def.id}>
                <label className="form-label">{def.attribute_name} {def.is_required && '*'}</label>
                <select
                  value={val}
                  onChange={(e) => handleValueChange(def.attribute_code, e.target.value)}
                  className="form-input"
                  required={def.is_required}
                >
                  <option value="">Select {def.attribute_name}</option>
                  {refOptions.map(opt => (
                    <option key={opt.id} value={opt.id}>{opt.name}</option>
                  ))}
                </select>
              </div>
            );
          }

          if (def.data_type === 'number') {
            return (
              <div key={def.id}>
                <label className="form-label">{def.attribute_name} {def.is_required && '*'}</label>
                <input
                  type="number"
                  step="any"
                  min="0"
                  value={val}
                  onChange={(e) => {
                    const value = e.target.value;

                    if (value === "" || Number(value) >= 0) {
                      handleValueChange(def.attribute_code, value);
                    }
                  }}
                  className="form-input"
                  placeholder={`Enter ${def.attribute_name}`}
                  required={def.is_required}
                />
              </div>
            );
          }

          if (def.data_type === 'date') {
            return (
              <div key={def.id}>
                <label className="form-label">{def.attribute_name} {def.is_required && '*'}</label>
                <input
                  type="date"
                  value={val}
                  onChange={(e) => handleValueChange(def.attribute_code, e.target.value)}
                  className="form-input"
                  required={def.is_required}
                />
              </div>
            );
          }

          if (def.data_type === 'boolean') {
            return (
              <div key={def.id} className="flex items-center gap-3 pt-2">
                <input
                  type="checkbox"
                  id={def.attribute_code}
                  checked={!!val}
                  onChange={(e) => handleValueChange(def.attribute_code, e.target.checked)}
                  className="w-4 h-4 rounded text-blue-600 bg-slate-900 border-white/10"
                />
                <label htmlFor={def.attribute_code} className="text-sm text-slate-200 cursor-pointer">
                  {def.attribute_name}
                </label>
              </div>
            );
          }

          return (
            <div key={def.id}>
              <label className="form-label">{def.attribute_name} {def.is_required && '*'}</label>
              <input
                type="text"
                value={val}
                onChange={(e) => handleValueChange(def.attribute_code, e.target.value)}
                className="form-input"
                placeholder={`Enter ${def.attribute_name}`}
                required={def.is_required}
              />
            </div>
          );
        })}

        <div>
          <label className="form-label">Remarks / Notes</label>
          <textarea
            value={formData.remarks}
            onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
            className="form-input"
            rows="2"
            placeholder="Additional notes for this process instance..."
          ></textarea>
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
        <button type="button" onClick={onCancel} className="btn-secondary">Cancel</button>
        <button type="submit" className="btn-primary">Launch Instance</button>
      </div>
    </form>
  );
}
