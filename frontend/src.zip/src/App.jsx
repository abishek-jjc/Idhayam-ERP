import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import StructuralMasters from './pages/StructuralMasters';
import DynamicMasters from './pages/DynamicMasters';
import ProcessEngine from './pages/ProcessEngine';
import WorkflowApprovals from './pages/WorkflowApprovals';
import JournalStock from './pages/JournalStock';
import AdminConsole from './pages/AdminConsole';
import LoginPage from './pages/LoginPage';
import UserPage from './pages/UserPage';

function ProtectedLayout() {
  return (
    <div className="app-container">
      <Sidebar />
      <div className="main-content">
        <Navbar title="ERP v2 Enterprise Workspace" />
        <div className="page-container">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/user" element={<UserPage />} />
            <Route path="/admin-console" element={<AdminConsole />} />
            <Route path="/structural-masters" element={<StructuralMasters />} />
            <Route path="/dynamic-masters" element={<DynamicMasters />} />
            <Route path="/process-engine" element={<ProcessEngine />} />
            <Route path="/workflow-approvals" element={<WorkflowApprovals />} />
            <Route path="/journal-stock" element={<JournalStock />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/*" element={<ProtectedLayout />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
