import React, { useEffect, useState } from 'react';
import { CoreAPI, ProcessEngineAPI, WorkflowAPI, JournalAPI } from '../api';
import { Building2, Users, Cpu, GitPullRequest, Boxes, Truck, CheckCircle2, TrendingUp } from 'lucide-react';

export default function Dashboard() {
  const [stats, setStats] = useState({
    plantsCount: 0,
    employeesCount: 0,
    machinesCount: 0,
    processTypesCount: 0,
    instancesCount: 0,
    proposalsCount: 0,
    stocksCount: 0,
  });
  const [recentInstances, setRecentInstances] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadDashboardData() {
      try {
        const [plantsRes, empRes, macRes, pTypeRes, instRes, propRes, stockRes] = await Promise.all([
          CoreAPI.getPlants(),
          CoreAPI.getEmployees(),
          CoreAPI.getMachines(),
          ProcessEngineAPI.getProcessTypes(),
          ProcessEngineAPI.getInstances(),
          WorkflowAPI.getProposals(),
          JournalAPI.getStocks(),
        ]);

        setStats({
          plantsCount: plantsRes.data.count || plantsRes.data.results?.length || plantsRes.data.length || 0,
          employeesCount: empRes.data.count || empRes.data.results?.length || empRes.data.length || 0,
          machinesCount: macRes.data.count || macRes.data.results?.length || macRes.data.length || 0,
          processTypesCount: pTypeRes.data.count || pTypeRes.data.results?.length || pTypeRes.data.length || 0,
          instancesCount: instRes.data.count || instRes.data.results?.length || instRes.data.length || 0,
          proposalsCount: propRes.data.count || propRes.data.results?.length || propRes.data.length || 0,
          stocksCount: stockRes.data.count || stockRes.data.results?.length || stockRes.data.length || 0,
        });

        setRecentInstances((instRes.data.results || instRes.data || []).slice(0, 5));
      } catch (err) {
        console.error("Failed to load dashboard statistics:", err);
      } finally {
        setLoading(false);
      }
    }
    loadDashboardData();
  }, []);

  const cardData = [
    { title: 'Active Plants & Units', count: stats.plantsCount, icon: Building2, color: 'from-blue-500 to-indigo-500' },
    { title: 'Total Workforce', count: stats.employeesCount, icon: Users, color: 'from-purple-500 to-pink-500' },
    { title: 'Machines & Vehicles', count: stats.machinesCount, icon: Truck, color: 'from-amber-500 to-orange-500' },
    { title: 'Dynamic Process Types', count: stats.processTypesCount, icon: Cpu, color: 'from-emerald-500 to-teal-500' },
    { title: 'Executed Process Instances', count: stats.instancesCount, icon: CheckCircle2, color: 'from-cyan-500 to-blue-500' },
    { title: 'Workflow Proposals', count: stats.proposalsCount, icon: GitPullRequest, color: 'from-rose-500 to-red-500' },
    { title: 'Tracked Bins & Stock', count: stats.stocksCount, icon: Boxes, color: 'from-indigo-500 to-violet-500' },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Top Welcome Banner */}
      <div className="glass-panel p-8 relative overflow-hidden bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-slate-900">
        <div className="relative z-10 space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
            <TrendingUp className="w-3.5 h-3.5" /> Next-Gen Enterprise Resource Engine
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Universal ERP <span className="gradient-text">v2 Dashboard</span>
          </h1>
          <p className="text-slate-300 text-sm max-w-2xl">
            Integrated Structural Masters, Dynamic Masters, Universal Movement Journal & Generic Process Engine running on MySQL.
          </p>
        </div>
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-gradient-to-l from-blue-500/10 to-transparent pointer-events-none"></div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {cardData.map((c, idx) => {
          const Icon = c.icon;
          return (
            <div key={idx} className="glass-panel p-5 relative overflow-hidden group hover:border-white/20 transition-all">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{c.title}</p>
                  <p className="text-2xl font-black text-white mt-1">{loading ? '...' : c.count}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${c.color} flex items-center justify-center text-white shadow-lg`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Process Instances Table */}
      <div className="glass-panel p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-blue-400" /> Recent Process Engine Executions
          </h3>
          <span className="text-xs text-slate-400">Live data from process_instance</span>
        </div>

        <div className="overflow-x-auto">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Instance ID</th>
                <th>Process Type</th>
                <th>Plant</th>
                <th>Department</th>
                <th>Status</th>
                <th>Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {recentInstances.length === 0 ? (
                <tr>
                  <td colSpan="6" className="text-center py-6 text-slate-500 italic">No process instances executed yet.</td>
                </tr>
              ) : (
                recentInstances.map((inst) => (
                  <tr key={inst.id}>
                    <td className="font-mono text-xs text-blue-400">{inst.id?.substring(0, 8)}...</td>
                    <td className="font-semibold text-white">{inst.process_type_name || 'Process'}</td>
                    <td>{inst.plant_name || '-'}</td>
                    <td>{inst.department_name || '-'}</td>
                    <td>
                      <span className={`badge badge-${inst.status}`}>
                        {inst.status}
                      </span>
                    </td>
                    <td className="text-xs text-slate-400">{new Date(inst.created_at).toLocaleString()}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
