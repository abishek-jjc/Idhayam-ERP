import React, { useEffect, useState } from 'react';
import { CoreAPI, MastersAPI, ProcessEngineAPI, WorkflowAPI, JournalAPI, AuthAPI } from '../api';
import Modal from '../components/Modal';
import Pagination from '../components/Pagination';
import { ShieldCheck, Database, Plus, Search, Eye, Edit2, Trash2, Download, Save, CheckSquare, Square, Layers, Cpu, Building2 } from 'lucide-react';

export default function AdminConsole() {
  const [adminTab, setAdminTab] = useState('permissions'); // 'permissions' | 'table_inspector'

  // Model Inspector States
  const [activeModel, setActiveModel] = useState('plants');
  const [data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const itemsPerPage = 10;
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  // Permission Matrix States
  const [designations, setDesignations] = useState([]);
  const [processTypes, setProcessTypes] = useState([]);
  const [selectedDesignationId, setSelectedDesignationId] = useState('');
  const [permMatrix, setPermMatrix] = useState([]);
  const [saveStatus, setSaveStatus] = useState('');

  const modelOptions = [
    { id: 'plants', label: 'Plants & Facilities', api: CoreAPI.getPlants },
    { id: 'departments', label: 'Departments', api: CoreAPI.getDepartments },
    { id: 'designations', label: 'Designations', api: CoreAPI.getDesignations },
    { id: 'employees', label: 'Employees', api: CoreAPI.getEmployees },
    { id: 'vendors', label: 'Vendors & Suppliers', api: CoreAPI.getVendors },
    { id: 'machines', label: 'Machines & Vehicles', api: CoreAPI.getMachines },
    { id: 'master_categories', label: 'Master Categories (MasterCategory)', api: MastersAPI.getCategories },
    { id: 'master_items', label: 'Master Items (MasterItem)', api: MastersAPI.getItems },
    { id: 'statutory_versions', label: 'Statutory Rule Versions (MasterItemVersion)', api: MastersAPI.getVersions },
    { id: 'master_attributes', label: 'Master Attributes (MasterAttribute)', api: MastersAPI.getAttributes },
    { id: 'master_instances', label: 'Master Instances (MasterInstance)', api: MastersAPI.getInstances },
    { id: 'master_attribute_values', label: 'Master Attribute Values (MasterAttributeValue)', api: MastersAPI.getAttributeValues },

    { id: 'process_types', label: 'Process Engine Types', api: ProcessEngineAPI.getProcessTypes },
    { id: 'process_instances', label: 'Process Executions', api: ProcessEngineAPI.getInstances },
    { id: 'workflow_proposals', label: 'Approval Proposals', api: WorkflowAPI.getProposals },
    { id: 'journal_entries', label: 'Journal Movements', api: JournalAPI.getEntries },
  ];

  const modulesList = [
    { code: 'dashboard', label: 'Executive Dashboard' },
    { code: 'structural_masters', label: 'Structural Masters (Plants/Dept)' },
    { code: 'dynamic_masters', label: 'Dynamic Masters Catalog' },
    { code: 'process_engine', label: 'Process Engine Executions' },
    { code: 'workflow', label: 'Workflow & Approvals' },
    { code: 'journal', label: 'Journal & Stock Ledger' },
    { code: 'admin', label: 'SuperAdmin Console' },
  ];

  useEffect(() => {
    loadDesignationsAndProcessTypes();
  }, []);

  useEffect(() => {
    if (adminTab === 'table_inspector') {
      loadModelData();
    }
  }, [activeModel, adminTab]);

  useEffect(() => {
    if (selectedDesignationId && adminTab === 'permissions') {
      loadDesignationPermissions(selectedDesignationId);
    }
  }, [selectedDesignationId, adminTab]);

  async function loadDesignationsAndProcessTypes() {
    try {
      const [desigRes, ptRes] = await Promise.all([
        CoreAPI.getDesignations(),
        ProcessEngineAPI.getProcessTypes(),
      ]);
      const desigList = desigRes.data.results || desigRes.data || [];
      const ptList = ptRes.data.results || ptRes.data || [];

      setDesignations(desigList);
      setProcessTypes(ptList);

      if (desigList.length > 0 && !selectedDesignationId) {
        setSelectedDesignationId(desigList[0].id);
      }
    } catch (err) {
      console.error("Error loading designations/process types:", err);
    }
  }

  async function loadDesignationPermissions(desigId) {
    try {
      const res = await CoreAPI.getPermissions({ designation: desigId });
      const perms = res.data.results || res.data || [];
      setPermMatrix(perms);
    } catch (err) {
      console.error("Error loading permissions:", err);
    }
  }

  async function loadModelData() {
    try {
      const option = modelOptions.find((m) => m.id === activeModel);
      if (option) {
        const res = await option.api();
        const results = res.data.results || res.data || [];
        setData(results);
        setCurrentPage(1);
      }
    } catch (err) {
      console.error("Error loading model data:", err);
    }
  }

  // Handle Permission Matrix updates locally
  const toggleModulePermission = (modCode, field) => {
    setPermMatrix((prev) => {
      const existingIdx = prev.findIndex((p) => p.module === modCode && !p.process_type);
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx] = {
          ...updated[existingIdx],
          [field]: !updated[existingIdx][field],
        };
        return updated;
      } else {
        return [
          ...prev,
          {
            module: modCode,
            can_view: field === 'can_view',
            can_create: field === 'can_create',
            can_edit: field === 'can_edit',
            can_delete: field === 'can_delete',
            can_approve: field === 'can_approve',
          },
        ];
      }
    });
  };

  const toggleProcessTypePermission = (ptId, field) => {
    setPermMatrix((prev) => {
      const existingIdx = prev.findIndex((p) => p.module === 'process_engine' && p.process_type === ptId);
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx] = {
          ...updated[existingIdx],
          [field]: !updated[existingIdx][field],
        };
        return updated;
      } else {
        return [
          ...prev,
          {
            module: 'process_engine',
            process_type: ptId,
            can_view: field === 'can_view',
            can_create: field === 'can_create',
            can_edit: field === 'can_edit',
            can_delete: field === 'can_delete',
            can_approve: field === 'can_approve',
          },
        ];
      }
    });
  };

  const handleSavePermissions = async () => {
    if (!selectedDesignationId) return;
    setSaveStatus('Saving permissions...');
    try {
      await AuthAPI.syncPermissions({
        designation_id: selectedDesignationId,
        permissions: permMatrix,
      });
      setSaveStatus('Permissions saved successfully!');
      setTimeout(() => setSaveStatus(''), 3000);
      loadDesignationPermissions(selectedDesignationId);
    } catch (err) {
      setSaveStatus('Failed to save: ' + (err.response?.data?.error || err.message));
    }
  };

  const activeDesignation = designations.find((d) => d.id === selectedDesignationId);

  const columns = data.length > 0 ? Object.keys(data[0]) : [];

  const filteredData = data.filter((row) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return Object.values(row).some(
      (val) => val !== null && val !== undefined && String(val).toLowerCase().includes(q)
    );
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage) || 1;
  const paginatedData = filteredData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const openViewModal = (record) => {
    setSelectedRecord(record);
    setViewModalOpen(true);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-7 h-7 text-purple-400" /> Super Admin Control Console
          </h1>
          <p className="text-xs text-slate-400">Designation Permission Matrix, Process Access Control, and Raw Table CRUD Inspection.</p>
        </div>

        {/* Console Tab Switcher */}
        <div className="flex p-1 bg-slate-950 rounded-xl border border-white/10 text-xs font-bold">
          <button
            onClick={() => setAdminTab('permissions')}
            className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
              adminTab === 'permissions' ? 'bg-purple-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" /> Designation Access Matrix
          </button>
          <button
            onClick={() => setAdminTab('table_inspector')}
            className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
              adminTab === 'table_inspector' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Database className="w-4 h-4" /> Raw Table Inspector
          </button>
        </div>
      </div>

      {/* TAB 1: DESIGNATION PERMISSION & PROCESS ACCESS MATRIX */}
      {adminTab === 'permissions' && (
        <div className="space-y-6">
          
          {/* Designation Selector Header */}
          <div className="glass-panel p-6 bg-slate-900/90 border border-purple-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Building2 className="w-6 h-6 text-purple-400" />
              <div>
                <label className="text-xs font-bold uppercase text-purple-400 tracking-wider">Select Designation to Edit:</label>
                <select
                  value={selectedDesignationId}
                  onChange={(e) => setSelectedDesignationId(e.target.value)}
                  className="form-input text-sm py-2 px-3 bg-slate-950 border border-purple-500/50 text-white font-bold rounded-xl cursor-pointer w-full md:w-80 mt-1"
                >
                  {designations.map((d) => (
                    <option key={d.id} value={d.id} className="bg-slate-900 text-white font-semibold">
                      {d.title} ({d.department_name || 'General'}) - Level {d.hierarchy_level}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {saveStatus && <span className="text-xs font-semibold text-emerald-400 animate-pulse">{saveStatus}</span>}
              <button onClick={handleSavePermissions} className="btn-primary text-xs flex items-center gap-2 px-5 py-2.5">
                <Save className="w-4 h-4" /> Save Designation Permissions
              </button>
            </div>
          </div>

          {/* Module & Process Access Matrix Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

            {/* Left Card: Page Module Permissions */}
            <div className="glass-panel p-6 space-y-4">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Layers className="w-5 h-5 text-indigo-400" /> Page & Module Level Access
                </h3>
                <p className="text-xs text-slate-400">Configure which main menu pages '{activeDesignation?.title}' can access.</p>
              </div>

              <div className="overflow-x-auto">
                <table className="custom-table text-xs">
                  <thead>
                    <tr>
                      <th>Module / Page</th>
                      <th className="text-center">View</th>
                      <th className="text-center">Create</th>
                      <th className="text-center">Edit</th>
                      <th className="text-center">Delete</th>
                      <th className="text-center">Approve</th>
                    </tr>
                  </thead>
                  <tbody>
                    {modulesList.map((mod) => {
                      const perm = permMatrix.find((p) => p.module === mod.code && !p.process_type) || {};
                      return (
                        <tr key={mod.code}>
                          <td className="font-semibold text-white">{mod.label}</td>
                          {['can_view', 'can_create', 'can_edit', 'can_delete', 'can_approve'].map((f) => (
                            <td key={f} className="text-center">
                              <button
                                onClick={() => toggleModulePermission(mod.code, f)}
                                className={`p-1 rounded transition-colors ${
                                  perm[f] ? 'text-emerald-400 hover:text-emerald-300' : 'text-slate-600 hover:text-slate-400'
                                }`}
                              >
                                {perm[f] ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                              </button>
                            </td>
                          ))}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right Card: Process Type Permissions */}
            <div className="glass-panel p-6 space-y-4">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-purple-400" /> Process Engine Type Access
                </h3>
                <p className="text-xs text-slate-400">Specify which Process Types can be executed by '{activeDesignation?.title}'.</p>
              </div>

              <div className="overflow-x-auto">
                <table className="custom-table text-xs">
                  <thead>
                    <tr>
                      <th>Process Type</th>
                      <th className="text-center">Allow View</th>
                      <th className="text-center">Allow Execute</th>
                      <th className="text-center">Sign-off / Approve</th>
                    </tr>
                  </thead>
                  <tbody>
                    {processTypes.length === 0 ? (
                      <tr>
                        <td colSpan="4" className="text-center py-6 text-slate-500 italic">No Process Types defined.</td>
                      </tr>
                    ) : (
                      processTypes.map((pt) => {
                        const perm = permMatrix.find((p) => p.module === 'process_engine' && (p.process_type === pt.id || p.process_type_code === pt.code)) || {};
                        return (
                          <tr key={pt.id}>
                            <td>
                              <p className="font-bold text-white text-xs">{pt.name}</p>
                              <span className="font-mono text-[10px] text-purple-400">{pt.code}</span>
                            </td>
                            <td className="text-center">
                              <button
                                onClick={() => toggleProcessTypePermission(pt.id, 'can_view')}
                                className={`p-1 rounded transition-colors ${
                                  perm.can_view !== false ? 'text-emerald-400 hover:text-emerald-300' : 'text-slate-600 hover:text-slate-400'
                                }`}
                              >
                                {perm.can_view !== false ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                              </button>
                            </td>
                            <td className="text-center">
                              <button
                                onClick={() => toggleProcessTypePermission(pt.id, 'can_create')}
                                className={`p-1 rounded transition-colors ${
                                  perm.can_create ? 'text-emerald-400 hover:text-emerald-300' : 'text-slate-600 hover:text-slate-400'
                                }`}
                              >
                                {perm.can_create ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                              </button>
                            </td>
                            <td className="text-center">
                              <button
                                onClick={() => toggleProcessTypePermission(pt.id, 'can_approve')}
                                className={`p-1 rounded transition-colors ${
                                  perm.can_approve ? 'text-purple-400 hover:text-purple-300' : 'text-slate-600 hover:text-slate-400'
                                }`}
                              >
                                {perm.can_approve ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* TAB 2: RAW TABLE INSPECTOR */}
      {adminTab === 'table_inspector' && (
        <div className="space-y-6">
          {/* Model Selector Navbar Dropdown */}
          <div className="glass-panel p-4 flex flex-col md:flex-row items-center justify-between gap-4 bg-slate-900/90 border border-purple-500/30">
            <div className="flex items-center gap-3 w-full md:w-auto">
              <span className="text-xs font-bold uppercase text-purple-400 tracking-wider whitespace-nowrap">Select Table Model:</span>
              <select
                value={activeModel}
                onChange={(e) => setActiveModel(e.target.value)}
                className="form-input text-xs py-2 px-3 bg-slate-950 border border-purple-500/50 text-white font-bold rounded-xl cursor-pointer w-full md:w-80"
              >
                {modelOptions.map(opt => (
                  <option key={opt.id} value={opt.id} className="bg-slate-900 text-white font-semibold">
                    {opt.label} ({opt.id})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Table Container */}
          <div className="glass-panel p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>{modelOptions.find((m) => m.id === activeModel)?.label}</span>
                <span className="badge badge-info text-xs">{filteredData.length} total rows</span>
              </h3>

              <div className="relative w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder={`Search ${activeModel}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="form-input pl-9 py-1.5 text-xs"
                />
              </div>
            </div>

            <div className="overflow-x-auto max-h-[500px]">
              <table className="custom-table text-xs">
                <thead className="sticky top-0 bg-slate-900 shadow-md">
                  <tr>
                    {columns.slice(0, 7).map((col) => (
                      <th key={col} className="capitalize">{col.replace(/_/g, ' ')}</th>
                    ))}
                    <th>Inspect</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedData.length === 0 ? (
                    <tr>
                      <td colSpan={columns.length + 1} className="text-center py-8 text-slate-500 italic">
                        No data records found for table model: {activeModel}.
                      </td>
                    </tr>
                  ) : (
                    paginatedData.map((row, idx) => (
                      <tr key={idx}>
                        {columns.slice(0, 7).map((col) => (
                          <td key={col} className="max-w-[200px] truncate">
                            {col === 'id' ? (
                              <span className="pk-badge">{String(row[col])}</span>
                            ) : typeof row[col] === 'object' && row[col] !== null ? (
                              <span className="font-mono text-[10px] text-emerald-400">{JSON.stringify(row[col]).substring(0, 25)}...</span>
                            ) : (
                              String(row[col] ?? '-')
                            )}
                          </td>
                        ))}
                        <td>
                          <button onClick={() => openViewModal(row)} className="p-1 hover:text-purple-400 text-slate-400" title="Inspect Record">
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              totalItems={filteredData.length}
              itemsPerPage={10}
            />
          </div>
        </div>
      )}

      {/* Inspect Modal */}
      <Modal isOpen={viewModalOpen} onClose={() => setViewModalOpen(false)} title={`Inspect Record in ${activeModel}`}>
        {selectedRecord && (
          <div className="space-y-3">
            <div className="bg-slate-950 p-4 rounded-xl border border-white/10 max-h-96 overflow-y-auto space-y-2">
              {Object.entries(selectedRecord).map(([key, value]) => (
                <div key={key} className="flex justify-between border-b border-white/5 pb-1 text-xs">
                  <span className="font-semibold text-slate-400 capitalize">{key.replace(/_/g, ' ')}:</span>
                  <span className="font-mono text-purple-300 ml-4 text-right break-all">
                    {typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value ?? 'null')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </Modal>

    </div>
  );
}
